function [time] = time(number)

time = (number^1.43 + number^1.13)/1000 - 5000;

end